<header>
    <nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">Picto Social</a>
    </div>
    
      <form class="navbar-form navbar-left">
          <div class="input-group">
            <input type="text" class="form-control" placeholder="Search Social Buzz...">
              <span class="input-group-btn">
                <button class="btn btn-default" type="button">Go!</button>
              </span>
          </div>
      </form>
      <ul class="nav navbar-nav navbar-center">
              <li><a href="#">Friends</a></li>
              <li><a href="#">Messages</a></li>
              <li><a href="#">Notifications</a></li>
      </ul>
        
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#">Profile</a></li>
        <li><a href="#">Home</a></li>
        <li><a href="<?php echo e(route('logout')); ?>">Logout</a></li>
      </ul>
    </div>
  </div>
</nav>
    
</header>